document.addEventListener('DOMContentLoaded', function() {
    const calorieModal = new bootstrap.Modal(document.getElementById('calorieModal'));
    const calorieResultModal = new bootstrap.Modal(document.getElementById('calorieResultModal'));

    window.calculateCalories = function() {
        const weight = parseFloat(document.getElementById('calWeight').value);
        const height = parseFloat(document.getElementById('calHeight').value);
        const age = parseInt(document.getElementById('calAge').value);
        const gender = document.getElementById('calGender').value;
        const activity = document.getElementById('calActivity').value;
        const goal = document.getElementById('calGoal').value;

        if (weight && height && age) {
            // BMR calculation using Mifflin-St Jeor Equation
            let bmr;
            if (gender === 'male') {
                bmr = 10 * weight + 6.25 * height - 5 * age + 5;
            } else {
                bmr = 10 * weight + 6.25 * height - 5 * age - 161;
            }

            // Activity multiplier
            const activityMultipliers = {
                'sedentary': 1.2,
                'light': 1.375,
                'moderate': 1.55,
                'active': 1.725,
                'very-active': 1.9
            };

            const maintenance = bmr * activityMultipliers[activity];

            // Adjust based on goal
            let targetCalories;
            let recommendation;
            switch(goal) {
                case 'lose':
                    targetCalories = maintenance - 500;
                    recommendation = 'Aim for a 500 calorie deficit for healthy weight loss';
                    break;
                case 'maintain':
                    targetCalories = maintenance;
                    recommendation = 'Focus on maintaining this calorie intake with balanced nutrition';
                    break;
                case 'gain':
                    targetCalories = maintenance + 500;
                    recommendation = 'Add 500 calories for healthy weight gain';
                    break;
            }

            // Generate meal distribution
            const meals = {
                breakfast: Math.round(targetCalories * 0.25),
                lunch: Math.round(targetCalories * 0.35),
                dinner: Math.round(targetCalories * 0.30),
                snacks: Math.round(targetCalories * 0.10)
            };

            document.getElementById('calorieResultContent').innerHTML = `
                <div class="text-center mb-4">
                    <h3>Your Daily Calorie Needs</h3>
                    <div class="display-4 text-primary mb-3">${Math.round(targetCalories)} kcal</div>
                    <p class="text-muted mb-4">${recommendation}</p>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h4>Daily Breakdown</h4>
                        <ul class="list-group mb-4">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>BMR:</span>
                                <strong>${Math.round(bmr)} kcal</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Maintenance:</span>
                                <strong>${Math.round(maintenance)} kcal</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Target:</span>
                                <strong>${Math.round(targetCalories)} kcal</strong>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h4>Suggested Meal Distribution</h4>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Breakfast:</span>
                                <strong>${meals.breakfast} kcal</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Lunch:</span>
                                <strong>${meals.lunch} kcal</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Dinner:</span>
                                <strong>${meals.dinner} kcal</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Snacks:</span>
                                <strong>${meals.snacks} kcal</strong>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="mt-4">
                    <h4>Tips for Success</h4>
                    <ul class="list-group">
                        <li class="list-group-item">Track your food intake using a food diary or app</li>
                        <li class="list-group-item">Stay hydrated by drinking at least 8 glasses of water daily</li>
                        <li class="list-group-item">Eat a balance of proteins, carbs, and healthy fats</li>
                        <li class="list-group-item">Include plenty of fruits, vegetables, and whole grains</li>
                    </ul>
                </div>
            `;

            calorieModal.hide();
            calorieResultModal.show();
        } else {
            alert('Please fill in all fields');
        }
    };
});
