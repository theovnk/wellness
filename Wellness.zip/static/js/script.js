// Global variables
const worldStats = {
    'North America': 77.6,
    'Europe': 78.3,
    'South America': 75.2,
    'Asia': 73.5,
    'Oceania': 77.8,
    'Africa': 63.2
};

let worldStatsChart = null;

// Initialize Bootstrap modals
const resultsModal = new bootstrap.Modal(document.getElementById('resultsModal'));
const worldStatsModal = new bootstrap.Modal(document.getElementById('worldStatsModal'));
const aboutModal = new bootstrap.Modal(document.getElementById('aboutModal'));

// Form submission handler
document.getElementById('calculatorForm').addEventListener('submit', function(e) {
    e.preventDefault();
    calculateLifeExpectancy();
});

// Calculate life expectancy
function calculateLifeExpectancy() {
    const formData = {
        gender: document.getElementById('gender').value,
        age: document.getElementById('age').value,
        smoking: document.getElementById('smoking').value,
        exercise: document.getElementById('exercise').value,
        height: parseFloat(document.getElementById('height').value),
        weight: parseFloat(document.getElementById('weight').value),
        diet: document.getElementById('diet').value,
        alcohol: document.getElementById('alcohol').value,
        chronicDiseases: document.getElementById('chronicDiseases').value,
        stressLevel: document.getElementById('stressLevel').value,
        medicalCheckups: document.getElementById('medicalCheckups').value,
        familyHistory: document.getElementById('familyHistory').value,
        socialLife: document.getElementById('socialLife').value,
        education: document.getElementById('education').value,
        maritalStatus: document.getElementById('maritalStatus').value
    };

    // Calculate BMI
    const heightInMeters = formData.height / 100;
    const bmi = formData.weight / (heightInMeters * heightInMeters);

    // Base life expectancy calculation
    let lifeExpectancy = 75;

    // Apply modifiers based on user inputs
    if (formData.age === '61+') lifeExpectancy -= 10;
    if (formData.smoking === 'Heavy') lifeExpectancy -= 10;
    if (formData.exercise === 'None') lifeExpectancy -= 5;
    if (formData.diet === 'Poor') lifeExpectancy -= 5;
    if (formData.alcohol === 'Heavy') lifeExpectancy -= 5;
    if (formData.chronicDiseases === '2+') lifeExpectancy -= 10    
    if (formData.stressLevel === 'High') lifeExpectancy -= 5;
    if (formData.medicalCheckups === 'Rare') lifeExpectancy -= 5;
    if (formData.familyHistory === 'Major Issues') lifeExpectancy -= 5;
    if (formData.socialLife === 'Limited') lifeExpectancy -= 5;
    if (formData.education === 'Basic') lifeExpectancy -= 5;
    if (formData.maritalStatus === 'Single') lifeExpectancy -= 2;

    // BMI adjustments
    if (bmi < 18.5 || bmi > 30) {
        lifeExpectancy -= 3;
    }

    // Gender adjustments
    if (formData.gender === 'Female') {
        lifeExpectancy += 5;
    }

    // Show results
    showResults(lifeExpectancy, bmi);
}

// Display results in modal
function showResults(lifeExpectancy, bmi) {
    const resultsContent = document.getElementById('resultsContent');
    resultsContent.innerHTML = `
        <div class="alert alert-info">
            <h4>Results:</h4>
            <p>Predicted Life Expectancy: ${lifeExpectancy.toFixed(1)} years</p>
            <p>BMI: ${bmi.toFixed(2)} (${getBMICategory(bmi)})</p>
        </div>
        <div class="alert alert-warning">
            <small>Note: This is an estimate based on statistical averages and should be used for informational purposes only.</small>
            <small>Note: Programmer: Theo van Niekerk 2024. All rights reserved. </small>

        </div>
    `;
    resultsModal.show();
}

// Get BMI category
function getBMICategory(bmi) {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal weight';
    if (bmi < 30) return 'Overweight';
    return 'Obese';
}

// Show world statistics
function showWorldStats() {
    const ctx = document.getElementById('worldStatsChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (worldStatsChart) {
        worldStatsChart.destroy();
    }

    // Create new chart
    worldStatsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(worldStats),
            datasets: [{
                label: 'Life Expectancy (years)',
                data: Object.values(worldStats),
                backgroundColor: '#3498db',
                borderColor: '#2980b9',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: false,
                    min: 60,
                    max: 85
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Life Expectancy by Continent'
                }
            }
        }
    });
    
    worldStatsModal.show();
}

// Show about information
function showAbout() {
    aboutModal.show();
}

// Reset form
function resetForm() {
    document.getElementById('calculatorForm').reset();
    // Reset height and weight to default values
    document.getElementById('height').value = '170';
    document.getElementById('weight').value = '70';
}
