document.addEventListener('DOMContentLoaded', function() {
    // Initialize the BMI Modal
    const bmiModal = new bootstrap.Modal(document.getElementById('bmiModal'));
    const bmiResultModal = new bootstrap.Modal(document.getElementById('bmiResultModal'));

    // BMI Calculator function
    window.calculateBMI = function() {
        const weight = parseFloat(document.getElementById('bmiWeight').value);
        const height = parseFloat(document.getElementById('bmiHeight').value) / 100; // convert cm to meters
        const age = parseInt(document.getElementById('bmiAge').value);
        const gender = document.getElementById('bmiGender').value;

        if (weight && height && age) {
            const bmi = weight / (height * height);
            const result = getBMICategory(bmi);
            const tips = getBMITips(result.category);

            document.getElementById('bmiResultContent').innerHTML = `
                <div class="text-center mb-4">
                    <h3>Your BMI Results</h3>
                    <div class="display-4 text-${result.colorClass} mb-3">${bmi.toFixed(1)}</div>
                    <p class="h5 mb-4">Category: ${result.category}</p>
                </div>
                <div class="tips-section">
                    <h4>Personalized Tips:</h4>
                    <ul class="list-group list-group-flush">
                        ${tips.map(tip => `<li class="list-group-item">${tip}</li>`).join('')}
                    </ul>
                </div>
            `;

            bmiModal.hide();
            bmiResultModal.show();
        } else {
            alert('Please fill in all fields');
        }
    };

    function getBMICategory(bmi) {
        if (bmi < 18.5) {
            return {
                category: 'Underweight',
                colorClass: 'warning'
            };
        } else if (bmi < 24.9) {
            return {
                category: 'Normal Weight',
                colorClass: 'success'
            };
        } else if (bmi < 29.9) {
            return {
                category: 'Overweight',
                colorClass: 'warning'
            };
        } else {
            return {
                category: 'Obese',
                colorClass: 'danger'
            };
        }
    }

    function getBMITips(category) {
        const tips = {
            'Underweight': [
                'Increase your caloric intake with nutrient-rich foods',
                'Include protein-rich foods in every meal',
                'Add healthy fats like nuts and avocados to your diet',
                'Consider strength training to build muscle mass',
                'Consult a nutritionist for a personalized meal plan'
            ],
            'Normal Weight': [
                'Maintain your balanced diet and exercise routine',
                'Stay hydrated with adequate water intake',
                'Continue regular physical activity',
                'Get regular health check-ups',
                'Focus on maintaining healthy habits'
            ],
            'Overweight': [
                'Incorporate more fruits and vegetables into your diet',
                'Practice portion control during meals',
                'Aim for 30 minutes of moderate exercise daily',
                'Replace sugary drinks with water',
                'Consider keeping a food diary'
            ],
            'Obese': [
                'Consult with healthcare provider for personalized advice',
                'Start with low-impact exercises like walking or swimming',
                'Focus on gradual, sustainable lifestyle changes',
                'Monitor your daily caloric intake',
                'Consider joining a support group or working with a dietitian'
            ]
        };
        return tips[category];
    }
});
