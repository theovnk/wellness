from flask import Flask, render_template, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# World statistics data
WORLD_STATS = {
    'North America': 77.6,
    'Europe': 78.3,
    'South America': 75.2,
    'Asia': 73.5,
    'Oceania': 77.8,
    'Africa': 63.2
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/world-stats')
def world_stats():
    return jsonify(WORLD_STATS)

if __name__ == '__main__':
    app.run(debug=True)
